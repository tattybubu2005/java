package com.finuniversity.store_system.controller;

import com.finuniversity.store_system.entity.Role;
import com.finuniversity.store_system.entity.User;
import com.finuniversity.store_system.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    // Форма регистрации
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        model.addAttribute("roles", Role.values());
        return "auth/register";
    }

    // Обработка регистрации
    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user) {
        userService.registerUser(user);
        return "redirect:/login?registered";
    }

    // Форма входа
    @GetMapping("/login")
    public String showLoginForm() {
        return "auth/login";
    }

    // Домашняя страница после входа
    @GetMapping("/dashboard")
    public String showDashboard() {
        return "dashboard";
    }
}