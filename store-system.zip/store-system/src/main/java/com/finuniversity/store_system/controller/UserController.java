package com.finuniversity.store_system.controller;

import com.finuniversity.store_system.entity.Role;
import com.finuniversity.store_system.entity.User;
import com.finuniversity.store_system.service.UserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/users")
@PreAuthorize("hasRole('ADMIN')")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Список всех пользователей
    @GetMapping
    public String listUsers(Model model) {
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "users/list";
    }

    // Форма создания пользователя
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("user", new User());
        model.addAttribute("roles", Role.values());
        return "users/form";
    }

    // Сохранение пользователя
    @PostMapping("/save")
    public String saveUser(@ModelAttribute User user) {
        userService.registerUser(user);
        return "redirect:/users";
    }

    // Форма редактирования пользователя
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        User user = userService.getUserById(id);
        model.addAttribute("user", user);
        model.addAttribute("roles", Role.values());
        return "users/form";
    }

    // Удаление пользователя (только не себя)
    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable("id") Long id, @AuthenticationPrincipal User currentUser) {
        if (!currentUser.getId().equals(id)) {
            userService.deleteUser(id);
        }
        return "redirect:/users";
    }
}