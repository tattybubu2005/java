// src/main/java/com/finuniversity/store_system/controller/ExportController.java
package com.finuniversity.store_system.controller;

import com.finuniversity.store_system.service.ExportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.time.LocalDate;

@Controller
@RequestMapping("/export")
@PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
public class ExportController {

    @Autowired
    private ExportService exportService;

    @GetMapping("/sales")
    public ResponseEntity<byte[]> exportSalesToExcel(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) throws IOException {

        // Если даты не указаны, используем разумные значения по умолчанию
        if (startDate == null) {
            startDate = LocalDate.now().minusMonths(1);
        }
        if (endDate == null) {
            endDate = LocalDate.now();
        }

        byte[] excelData = exportService.exportSalesToExcel(startDate, endDate);

        String filename = String.format("sales_%s_%s.xlsx",
                startDate.toString(), endDate.toString());

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + filename + "\"")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(excelData);
    }
}