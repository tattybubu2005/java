// src/main/java/com/finuniversity/store_system/repository/CartItemRepository.java
package com.finuniversity.store_system.repository;

import com.finuniversity.store_system.entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    void deleteByCartId(Long cartId);
}