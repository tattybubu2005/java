package com.finuniversity.store_system.service;

import com.finuniversity.store_system.entity.Product;
import com.finuniversity.store_system.entity.Sale;
import com.finuniversity.store_system.repository.ProductRepository;
import com.finuniversity.store_system.repository.SaleRepository;
import com.finuniversity.store_system.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ReportService {

    private final SaleRepository saleRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public ReportService(SaleRepository saleRepository,
                         ProductRepository productRepository,
                         UserRepository userRepository) {
        this.saleRepository = saleRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    // 1. Основная статистика (новые методы)

    public long getTotalUsers() {
        return userRepository.count();
    }

    public long getTotalProducts() {
        return productRepository.count();
    }

    public long getTotalSales() {
        return saleRepository.count();
    }

    // Ваш существующий метод
    public BigDecimal getTotalRevenue() {
        List<Sale> sales = saleRepository.findAll();
        return sales.stream()
                .map(Sale::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public BigDecimal getAverageCheck() {
        List<Sale> sales = saleRepository.findAll();
        if (sales.isEmpty()) return BigDecimal.ZERO;

        BigDecimal total = getTotalRevenue();
        return total.divide(BigDecimal.valueOf(sales.size()), 2);
    }


    // 2. Ваши существующие методы (оставляем как есть)

    public Map<String, Long> getSalesByMonth() {
        Map<String, Long> salesByMonth = new HashMap<>();
        List<Sale> sales = saleRepository.findAll();

        // Группировка по месяцам (для простоты - по количеству продаж)
        sales.stream()
                .collect(Collectors.groupingBy(
                        sale -> YearMonth.from(sale.getSaleDate()),
                        Collectors.counting()
                ))
                .forEach((yearMonth, count) -> {
                    salesByMonth.put(yearMonth.toString(), count);
                });

        return salesByMonth;
    }

    public Map<String, Object> getSalesStatistics() {
        Map<String, Object> stats = new HashMap<>();
        List<Sale> sales = saleRepository.findAll();

        if (!sales.isEmpty()) {
            // Общее количество продаж
            stats.put("totalSales", sales.size());

            // Общая выручка
            BigDecimal totalRevenue = sales.stream()
                    .map(Sale::getTotalAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            stats.put("totalRevenue", totalRevenue);

            // Средний чек
            BigDecimal averageCheck = totalRevenue.divide(BigDecimal.valueOf(sales.size()), 2);
            stats.put("averageCheck", averageCheck);

            // Продажи за последние 30 дней
            LocalDate monthAgo = LocalDate.now().minusDays(30);
            long recentSales = sales.stream()
                    .filter(sale -> sale.getSaleDate().toLocalDate().isAfter(monthAgo))
                    .count();
            stats.put("recentSales", recentSales);
        }

        return stats;
    }

    public List<Product> getTopSellingProducts(int limit) {
        // В реальном приложении здесь был бы сложный запрос
        // Сейчас вернем просто товары с самым большим остатком
        return productRepository.findAll().stream()
                .sorted((p1, p2) -> Integer.compare(p2.getQuantity(), p1.getQuantity()))
                .limit(limit)
                .collect(Collectors.toList());
    }

    public List<Product> getLowStockProducts() {
        return productRepository.findAll().stream()
                .filter(product -> product.getQuantity() < 10) // Меньше 10 штук
                .collect(Collectors.toList());
    }

    // 3. Новые методы для отчетов

    public Map<String, Long> getProductsByCategory() {
        Map<String, Long> categoryStats = new HashMap<>();

        // Временные данные для демонстрации
        // В реальном проекте здесь был бы запрос к БД
        categoryStats.put("Молочные продукты", 25L);
        categoryStats.put("Хлебобулочные изделия", 18L);
        categoryStats.put("Напитки", 32L);
        categoryStats.put("Консервы", 12L);
        categoryStats.put("Сладости", 15L);

        return categoryStats;
    }

    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();

        stats.put("totalUsers", getTotalUsers());
        stats.put("totalProducts", getTotalProducts());
        stats.put("totalSales", getTotalSales());
        stats.put("totalRevenue", getTotalRevenue());
        stats.put("averageCheck", getAverageCheck());
        stats.put("salesByMonth", getSalesByMonth());
        stats.put("categoryStats", getProductsByCategory());

        return stats;
    }
}