package com.finuniversity.store_system.config;

import com.finuniversity.store_system.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final UserService userService;
    private final BCryptPasswordEncoder passwordEncoder;

    public SecurityConfig(UserService userService, BCryptPasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable()) // Временно отключаем CSRF для тестирования
                .authorizeHttpRequests(auth -> auth
                        // Публичные страницы
                        .requestMatchers("/", "/register", "/login", "/css/**", "/js/**").permitAll()

                        // Страницы по ролям
                        .requestMatchers("/admin/**", "/users/**").hasRole("ADMIN")
                        .requestMatchers("/sales/**").hasAnyRole("ADMIN", "CASHIER")
                        .requestMatchers("/reports/**").hasAnyRole("ADMIN", "MANAGER")
                        .requestMatchers("/warehouse/**").hasAnyRole("ADMIN", "STOCKER")

                        // Общие страницы для авторизованных
                        .requestMatchers("/products/**", "/categories/**").authenticated()
                        .requestMatchers("/dashboard").authenticated()

                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")          // Страница логина
                        .loginProcessingUrl("/login") // URL для обработки POST запроса логина
                        .defaultSuccessUrl("/dashboard", true) // Редирект после успешного входа
                        .failureUrl("/login?error")   // Редирект при ошибке
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")         // URL для выхода
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                );

        return http.build();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userService);
        authProvider.setPasswordEncoder(passwordEncoder);
        return authProvider;
    }
}