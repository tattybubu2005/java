package com.finuniversity.store_system.controller;

import com.finuniversity.store_system.entity.*;
import com.finuniversity.store_system.repository.ProductRepository;
import com.finuniversity.store_system.service.SaleService;
import com.finuniversity.store_system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/sales")
@PreAuthorize("hasAnyRole('ADMIN', 'CASHIER')")
@SessionAttributes("currentSale") // Для хранения текущей продажи в сессии
public class SaleController {

    @Autowired
    private SaleService saleService;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserService userService;

    // ===== СЕССИОННЫЙ АТРИБУТ =====
    // Инициализация текущей продажи в сессии
    @ModelAttribute("currentSale")
    public Sale getCurrentSale() {
        return saleService.createSale();
    }

    // ===== ГЛАВНАЯ СТРАНИЦА ПРОДАЖ =====
    @GetMapping
    public String listSales(Model model,
                            @RequestParam(required = false) String startDate,
                            @RequestParam(required = false) String endDate,
                            @RequestParam(required = false) String cashierUsername) {

        List<Sale> sales;

        // Фильтрация по датам
        if (startDate != null && !startDate.isEmpty() &&
                endDate != null && !endDate.isEmpty()) {
            try {
                LocalDate start = LocalDate.parse(startDate);
                LocalDate end = LocalDate.parse(endDate);
                sales = saleService.getSalesByDateRange(start, end);
                model.addAttribute("startDate", startDate);
                model.addAttribute("endDate", endDate);
            } catch (Exception e) {
                sales = saleService.getAllSales();
                model.addAttribute("error", "Неверный формат даты. Используйте ГГГГ-ММ-ДД");
            }
        } else {
            // Все продажи
            sales = saleService.getAllSales();
        }

        // Фильтрация по кассиру
        if (cashierUsername != null && !cashierUsername.isEmpty()) {
            sales = sales.stream()
                    .filter(sale -> sale.getCashier() != null &&
                            sale.getCashier().getUsername().contains(cashierUsername))
                    .toList();
            model.addAttribute("cashierUsername", cashierUsername);
        }

        model.addAttribute("sales", sales);

        // Статистика за последний месяц
        LocalDate today = LocalDate.now();
        LocalDate monthAgo = today.minusMonths(1);
        model.addAttribute("stats", saleService.getSalesStatistics(monthAgo, today));

        return "sales/list";
    }

    // ===== НОВАЯ ПРОДАЖА =====
    @GetMapping("/new")
    @PreAuthorize("hasRole('CASHIER')")
    public String newSale(Model model,
                          @ModelAttribute("currentSale") Sale currentSale,
                          @RequestParam(required = false) String error,
                          @RequestParam(required = false) String success) {

        List<Product> products = productRepository.findAll();
        model.addAttribute("products", products);
        model.addAttribute("sale", currentSale);

        if (error != null) {
            model.addAttribute("errorMessage", error);
        }
        if (success != null) {
            model.addAttribute("successMessage", success);
        }

        return "sales/new";
    }

    // ===== ДОБАВИТЬ ТОВАР В ПРОДАЖУ =====
    @PostMapping("/add-item")
    public String addItemToSale(@ModelAttribute("currentSale") Sale currentSale,
                                @RequestParam Long productId,
                                @RequestParam Integer quantity,
                                @AuthenticationPrincipal User currentUser) {

        try {
            // Проверяем, что кассир авторизован
            if (currentUser == null) {
                return "redirect:/sales/new?error=Требуется авторизация";
            }

            // Устанавливаем кассира для продажи, если еще не установлен
            if (currentSale.getCashier() == null) {
                currentSale.setCashier(currentUser);
            }

            saleService.addProductToSale(currentSale, productId, quantity);
            return "redirect:/sales/new?success=Товар успешно добавлен";

        } catch (IllegalArgumentException e) {
            return "redirect:/sales/new?error=" + e.getMessage();
        } catch (RuntimeException e) {
            return "redirect:/sales/new?error=" + e.getMessage();
        }
    }
    // В SaleController добавьте метод:
    @GetMapping("/daily")
    public String dailyReport(Model model,
                              @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        LocalDate reportDate = date != null ? date : LocalDate.now();

        // Получаем продажи за выбранный день
        List<Sale> dailySales = saleService.getSalesByDateRange(reportDate, reportDate);
        Map<String, Object> stats = saleService.getSalesStatistics(reportDate, reportDate);

        // Рассчитываем общую выручку за день
        BigDecimal totalRevenue = dailySales.stream()
                .map(Sale::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        model.addAttribute("sales", dailySales);
        model.addAttribute("reportDate", reportDate);
        model.addAttribute("stats", stats);
        model.addAttribute("totalSales", dailySales.size());
        model.addAttribute("totalRevenue", totalRevenue);

        return "sales/daily-report";
    }

    // ===== УДАЛИТЬ ТОВАР ИЗ ПРОДАЖИ =====
    @GetMapping("/remove-item/{productId}")
    public String removeItemFromSale(@ModelAttribute("currentSale") Sale currentSale,
                                     @PathVariable Long productId) {
        try {
            saleService.removeProductFromSale(currentSale, productId);
            return "redirect:/sales/new?success=Товар удален из продажи";
        } catch (RuntimeException e) {
            return "redirect:/sales/new?error=" + e.getMessage();
        }
    }

    // ===== ИЗМЕНИТЬ КОЛИЧЕСТВО ТОВАРА =====
    @PostMapping("/update-quantity/{productId}")
    public String updateQuantity(@ModelAttribute("currentSale") Sale currentSale,
                                 @PathVariable Long productId,
                                 @RequestParam Integer newQuantity) {
        try {
            if (newQuantity <= 0) {
                // Если количество стало 0 или меньше, удаляем товар
                saleService.removeProductFromSale(currentSale, productId);
                return "redirect:/sales/new?success=Товар удален из продажи";
            }

            // Находим товар и обновляем количество
            SaleItem item = currentSale.getItems().stream()
                    .filter(i -> i.getProduct().getId().equals(productId))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Товар не найден"));

            // Проверяем остаток на складе
            Product product = productRepository.findById(productId)
                    .orElseThrow(() -> new RuntimeException("Товар не найден"));

            if (product.getQuantity() < newQuantity) {
                throw new RuntimeException("Недостаточно товара. Доступно: " + product.getQuantity());
            }

            item.setQuantity(newQuantity);
            currentSale.calculateTotal();

            return "redirect:/sales/new?success=Количество обновлено";

        } catch (RuntimeException e) {
            return "redirect:/sales/new?error=" + e.getMessage();
        }
    }

    // ===== ЗАВЕРШИТЬ ПРОДАЖУ =====
    @PostMapping("/complete")
    public String completeSale(@ModelAttribute("currentSale") Sale currentSale,
                               @AuthenticationPrincipal User currentUser,
                               SessionStatus sessionStatus) {
        try {
            // Проверяем, что есть товары в продаже
            if (currentSale == null || currentSale.getItems().isEmpty()) {
                return "redirect:/sales/new?error=Невозможно завершить пустую продажу";
            }

            // Завершаем продажу
            Sale completedSale = saleService.completeSale(currentSale, currentUser.getId());

            // Очищаем сессию
            sessionStatus.setComplete();

            return "redirect:/sales?success=Продажа #" + completedSale.getId() + " успешно завершена. Сумма: " +
                    completedSale.getTotalAmount() + " руб.";

        } catch (RuntimeException e) {
            return "redirect:/sales/new?error=" + e.getMessage();
        }
    }

    // ===== ОТМЕНА ТЕКУЩЕЙ ПРОДАЖИ =====
    @GetMapping("/cancel")
    public String cancelSale(SessionStatus sessionStatus,
                             @RequestParam(required = false) String redirectTo) {
        sessionStatus.setComplete();

        if ("dashboard".equals(redirectTo)) {
            return "redirect:/dashboard";
        }
        return "redirect:/sales";
    }

    // ===== ДЕТАЛИ ПРОДАЖИ =====
    @GetMapping("/details/{id}")
    public String saleDetails(@PathVariable Long id, Model model) {
        try {
            Sale sale = saleService.getAllSales().stream()
                    .filter(s -> s.getId().equals(id))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Продажа не найдена"));

            model.addAttribute("sale", sale);
            return "sales/details";

        } catch (RuntimeException e) {
            model.addAttribute("error", e.getMessage());
            return "redirect:/sales";
        }
    }

    // ===== ПОВТОРИТЬ ПРОДАЖУ =====
    @GetMapping("/repeat/{id}")
    public String repeatSale(@PathVariable Long id,
                             @ModelAttribute("currentSale") Sale currentSale,
                             SessionStatus sessionStatus) {
        try {
            // Очищаем текущую сессию
            sessionStatus.setComplete();

            // Находим старую продажу
            Sale oldSale = saleService.getAllSales().stream()
                    .filter(s -> s.getId().equals(id))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Продажа не найдена"));

            // Создаем новую продажу с теми же товарами
            Sale newSale = saleService.createSale();

            for (SaleItem oldItem : oldSale.getItems()) {
                try {
                    saleService.addProductToSale(newSale, oldItem.getProduct().getId(), oldItem.getQuantity());
                } catch (Exception e) {
                    // Пропускаем товары, которых нет в наличии
                }
            }

            return "redirect:/sales/new?success=Продажа #" + id + " скопирована";

        } catch (RuntimeException e) {
            return "redirect:/sales?error=" + e.getMessage();
        }
    }

    // ===== ЭКСПОРТ В EXCEL =====
    @GetMapping("/export")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    public String exportSales(@RequestParam(required = false) String startDate,
                              @RequestParam(required = false) String endDate,
                              @RequestParam(required = false) String format) {

        // Здесь будет логика экспорта
        // Для курсовой можно сделать простой экспорт в CSV
        String exportFormat = (format != null) ? format : "csv";

        if ("csv".equalsIgnoreCase(exportFormat)) {
            // TODO: Реализовать экспорт в CSV
            return "redirect:/sales?message=Экспорт в CSV (в разработке)";
        } else if ("excel".equalsIgnoreCase(exportFormat)) {
            // TODO: Реализовать экспорт в Excel
            return "redirect:/sales?message=Экспорт в Excel (в разработке)";
        } else if ("pdf".equalsIgnoreCase(exportFormat)) {
            // TODO: Реализовать экспорт в PDF
            return "redirect:/sales?message=Экспорт в PDF (в разработке)";
        }

        return "redirect:/sales?error=Неизвестный формат экспорта";
    }

    // ===== БЫСТРАЯ ПРОДАЖА =====
    @GetMapping("/quick")
    @PreAuthorize("hasRole('CASHIER')")
    public String quickSale(Model model) {
        // Страница для быстрых продаж (популярные товары)
        List<Product> popularProducts = productRepository.findAll().stream()
                .filter(p -> p.getQuantity() > 0)
                .limit(10)
                .toList();

        model.addAttribute("popularProducts", popularProducts);
        return "sales/quick";
    }

    // ===== API ДЛЯ AJAX =====
    @GetMapping("/api/items/{id}")
    @ResponseBody
    public List<SaleItem> getSaleItems(@PathVariable Long id) {
        Sale sale = saleService.getAllSales().stream()
                .filter(s -> s.getId().equals(id))
                .findFirst()
                .orElse(null);

        return (sale != null) ? sale.getItems() : List.of();
    }
}