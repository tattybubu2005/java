package com.finuniversity.store_system.entity;

public enum Role {
    ADMIN,      // Администратор
    CASHIER,    // Кассир
    MANAGER,    // Менеджер
    STOCKER     // Кладовщик
}