// src/main/java/com/finuniversity/store_system/repository/CartRepository.java
package com.finuniversity.store_system.repository;

import com.finuniversity.store_system.entity.Cart;
import com.finuniversity.store_system.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {
    Optional<Cart> findByUser(User user);
    Optional<Cart> findByUserId(Long userId);
}