package com.finuniversity.store_system.controller;

import com.finuniversity.store_system.service.UserService;
import com.finuniversity.store_system.service.SaleService;
import com.finuniversity.store_system.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/reports")
@PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
public class ReportController {

    private final UserService userService;
    private final SaleService saleService;
    private final ProductService productService;

    @Autowired
    public ReportController(UserService userService,
                            SaleService saleService,
                            ProductService productService) {
        this.userService = userService;
        this.saleService = saleService;
        this.productService = productService;
    }

    // Главная страница отчетов
    @GetMapping
    public String reportsDashboard(Model model) {
        // Базовая статистика
        long totalUsers = userService.getAllUsers().size();

        // Получаем статистику продаж
        Map<String, Object> salesStats = saleService.getSalesStatistics();
        BigDecimal totalRevenue = (BigDecimal) salesStats.getOrDefault("totalRevenue", BigDecimal.ZERO);
        Integer totalSales = (Integer) salesStats.getOrDefault("totalSales", 0);
        BigDecimal averageCheck = (BigDecimal) salesStats.getOrDefault("averageCheck", BigDecimal.ZERO);
        Integer recentSales = (Integer) salesStats.getOrDefault("recentSales", 0);

        // Данные для графиков
        Map<YearMonth, BigDecimal> monthlyRevenue = saleService.getMonthlyRevenue();
        Map<String, Long> paymentMethods = saleService.getSalesByPaymentMethod();

        // Статистика по товарам
        long totalProducts = productService.getTotalProducts();
        BigDecimal totalInventoryValue = productService.getTotalInventoryValue();
        List<Object[]> topProducts = productService.getTopSellingProducts(10);
        List<Object[]> lowStockProducts = productService.getLowStockProducts(10);
        List<Object[]> productsByCategory = productService.getProductsByCategory();

        // Рассчитываем проценты для категорий
        Map<String, Long> categoryPercentages = calculateCategoryPercentages(productsByCategory, totalProducts);

        // Передаем все данные в модель
        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("totalSales", totalSales);
        model.addAttribute("averageCheck", averageCheck);
        model.addAttribute("recentSales", recentSales);
        model.addAttribute("monthlyRevenue", monthlyRevenue);
        model.addAttribute("paymentMethods", paymentMethods);
        model.addAttribute("totalProducts", totalProducts);
        model.addAttribute("totalInventoryValue", totalInventoryValue);
        model.addAttribute("topProducts", topProducts);
        model.addAttribute("lowStockProducts", lowStockProducts);
        model.addAttribute("productsByCategory", productsByCategory);
        model.addAttribute("categoryPercentages", categoryPercentages);

        return "reports/dashboard";
    }

    // Отчет по продажам с фильтрацией по датам
    @GetMapping("/sales")
    public String salesReport(Model model,
                              @RequestParam(required = false) String startDate,
                              @RequestParam(required = false) String endDate) {

        LocalDate start = startDate != null ? LocalDate.parse(startDate) : LocalDate.now().minusDays(30);
        LocalDate end = endDate != null ? LocalDate.parse(endDate) : LocalDate.now();

        Map<String, Object> salesStats = saleService.getSalesStatistics(start, end);
        Map<YearMonth, BigDecimal> monthlyRevenue = saleService.getMonthlyRevenue();
        Map<String, Long> paymentMethods = saleService.getSalesByPaymentMethod();

        // Получаем топ товаров из ProductService (можно также из SaleService)
        List<Object[]> topSellingProducts = productService.getTopSellingProducts(10);

        model.addAttribute("salesStats", salesStats);
        model.addAttribute("monthlyRevenue", monthlyRevenue);
        model.addAttribute("paymentMethods", paymentMethods);
        model.addAttribute("topSellingProducts", topSellingProducts);
        model.addAttribute("startDate", start);
        model.addAttribute("endDate", end);

        return "reports/sales";
    }

    // Отчет по товарам
    @GetMapping("/products")
    public String productsReport(Model model) {
        List<Object[]> topProducts = productService.getTopSellingProducts(20);
        List<Object[]> lowStockProducts = productService.getLowStockProducts(20);
        List<Object[]> productsByCategory = productService.getProductsByCategory();
        List<Object[]> mostExpensiveProducts = productService.getMostExpensiveProducts(10);
        List<Object[]> productsRunningOut = productService.getProductsRunningOut();

        // Общая статистика товаров
        long totalProducts = productService.getTotalProducts();
        BigDecimal totalInventoryValue = productService.getTotalInventoryValue();

        model.addAttribute("topProducts", topProducts);
        model.addAttribute("lowStockProducts", lowStockProducts);
        model.addAttribute("productsByCategory", productsByCategory);
        model.addAttribute("mostExpensiveProducts", mostExpensiveProducts);
        model.addAttribute("productsRunningOut", productsRunningOut);
        model.addAttribute("totalProducts", totalProducts);
        model.addAttribute("totalInventoryValue", totalInventoryValue);

        return "reports/products";
    }

    // Отчет по категориям
    @GetMapping("/categories")
    public String categoriesReport(Model model) {
        List<Object[]> categoryData = productService.getProductsByCategory();
        long totalProducts = productService.getTotalProducts();

        model.addAttribute("categoryData", categoryData);
        model.addAttribute("totalProducts", totalProducts);

        return "reports/categories";
    }

    // Вспомогательный метод для расчета процентов по категориям
    private Map<String, Long> calculateCategoryPercentages(List<Object[]> categoryData, long totalProducts) {
        Map<String, Long> percentages = new java.util.HashMap<>();

        if (totalProducts > 0) {
            for (Object[] data : categoryData) {
                if (data[0] != null && data[1] != null) {
                    String categoryName = (String) data[0];
                    Long productCount = ((Number) data[1]).longValue();
                    long percentage = (productCount * 100) / totalProducts;
                    percentages.put(categoryName, percentage);
                }
            }
        }

        return percentages;
    }
}