// src/main/java/com/finuniversity/store_system/service/ProductService.java
package com.finuniversity.store_system.service;

import com.finuniversity.store_system.entity.Product;
import com.finuniversity.store_system.entity.Category;
import com.finuniversity.store_system.repository.ProductRepository;
import com.finuniversity.store_system.repository.CategoryRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @PersistenceContext
    private EntityManager entityManager;

    // ==================== БАЗОВЫЕ ОПЕРАЦИИ ====================

    /**
     * Получить все товары
     */
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    /**
     * Получить товар по ID
     */
    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Товар не найден с ID: " + id));
    }

    /**
     * Сохранить товар
     */
    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    /**
     * Удалить товар
     */
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    /**
     * Найти товары по названию
     */
    public List<Product> searchProductsByName(String name) {
        return productRepository.findByNameContainingIgnoreCase(name);
    }

    /**
     * Найти товары по категории
     */
    public List<Product> getProductsByCategory(Long categoryId) {
        return productRepository.findByCategoryId(categoryId);
    }

    /**
     * Получить количество товаров
     */
    public long getTotalProducts() {
        return productRepository.count();
    }

    // ==================== БИЗНЕС-ЛОГИКА ====================

    /**
     * Увеличить остаток товара
     */
    public Product increaseStock(Long productId, Integer quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Количество должно быть больше 0");
        }

        Product product = getProductById(productId);
        product.setQuantity(product.getQuantity() + quantity);
        return productRepository.save(product);
    }

    /**
     * Уменьшить остаток товара
     */
    public Product decreaseStock(Long productId, Integer quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Количество должно быть больше 0");
        }

        Product product = getProductById(productId);
        if (product.getQuantity() < quantity) {
            throw new RuntimeException("Недостаточно товара на складе. Доступно: " + product.getQuantity());
        }

        product.setQuantity(product.getQuantity() - quantity);
        return productRepository.save(product);
    }

    /**
     * Обновить цену товара
     */
    public Product updatePrice(Long productId, BigDecimal newPrice) {
        if (newPrice.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Цена должна быть больше 0");
        }

        Product product = getProductById(productId);
        product.setPrice(newPrice);
        return productRepository.save(product);
    }

    /**
     * Проверить срок годности товаров
     */
    public List<Product> getExpiringProducts(int daysThreshold) {
        LocalDate thresholdDate = LocalDate.now().plusDays(daysThreshold);

        return productRepository.findAll().stream()
                .filter(product -> product.getExpirationDate() != null)
                .filter(product -> product.getExpirationDate().isBefore(thresholdDate))
                .collect(Collectors.toList());
    }

    // ==================== ОТЧЕТЫ И СТАТИСТИКА ====================

    /**
     * Получить топ товаров по остаткам
     */
    public List<Object[]> getTopProductsByStock(int limit) {
        String sql = """
            SELECT p.id, p.name, p.article, p.price, p.quantity,
                   (p.price * p.quantity) as total_value
            FROM products p
            ORDER BY p.quantity DESC
            LIMIT :limit
            """;

        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("limit", limit);

        return query.getResultList();
    }

    /**
     * Получить товары с низким запасом (исправленная версия с английскими статусами)
     */
    public List<Object[]> getLowStockProducts(int threshold) {
        String sql = "SELECT p.id, p.name, p.article, p.price, p.quantity, " +
                "CASE WHEN p.quantity < 5 THEN 'CRITICAL' " +
                "     WHEN p.quantity < 10 THEN 'LOW' " +
                "     ELSE 'NORMAL' END as stock_status " +
                "FROM products p " +
                "WHERE p.quantity < ?1 " +
                "ORDER BY p.quantity ASC";

        Query query = entityManager.createNativeQuery(sql);
        query.setParameter(1, threshold);

        return query.getResultList();
    }
    /**
     * Получить товары с низким запасом (по умолчанию < 10)
     */
    public List<Object[]> getLowStockProducts() {
        return getLowStockProducts(10);
    }

    /**
     * Получить топ товаров по продажам (улучшенная версия)
     */
    public List<Object[]> getTopSellingProducts(int limit) {
        String sql = """
            SELECT p.id, p.name, p.article, 
                   COALESCE(SUM(si.quantity), 0) as total_sold,
                   COALESCE(SUM(si.quantity * si.price), 0) as total_revenue,
                   p.price as current_price,
                   p.quantity as current_stock
            FROM products p
            LEFT JOIN sale_items si ON p.id = si.product_id
            LEFT JOIN sales s ON si.sale_id = s.id
            GROUP BY p.id, p.name, p.article, p.price, p.quantity
            ORDER BY total_sold DESC
            LIMIT :limit
            """;

        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("limit", limit);

        return query.getResultList();
    }

    /**
     * Альтернативный метод для получения топ товаров по продажам (упрощенный JOIN)
     */
    public List<Object[]> getTopSellingProductsSimple(int limit) {
        String sql = """
            SELECT p.id, p.name, p.article, 
                   SUM(si.quantity) as total_sold,
                   SUM(si.quantity * si.price) as total_revenue
            FROM sale_items si
            JOIN products p ON si.product_id = p.id
            GROUP BY p.id, p.name, p.article
            ORDER BY total_sold DESC
            LIMIT :limit
            """;

        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("limit", limit);

        return query.getResultList();
    }

    /**
     * Получить статистику по категориям (улучшенная версия с total_value)
     */
    public List<Object[]> getProductsByCategory() {
        String sql = """
            SELECT 
                COALESCE(c.name, 'Без категории') as category_name,
                COUNT(p.id) as product_count,
                SUM(p.quantity) as total_quantity,
                AVG(p.price) as avg_price,
                SUM(p.price * p.quantity) as total_value
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            GROUP BY c.name
            ORDER BY product_count DESC
            """;

        Query query = entityManager.createNativeQuery(sql);
        return query.getResultList();
    }

    /**
     * Альтернативный метод для получения статистики по категориям (упрощенный)
     */
    public List<Object[]> getProductsByCategorySimple() {
        String sql = """
            SELECT c.name as category_name,
                   COUNT(p.id) as product_count,
                   SUM(p.quantity) as total_quantity,
                   AVG(p.price) as avg_price
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            GROUP BY c.name
            ORDER BY product_count DESC
            """;

        Query query = entityManager.createNativeQuery(sql);
        return query.getResultList();
    }

    /**
     * Получить общую стоимость всех товаров на складе
     */
    public BigDecimal getTotalInventoryValue() {
        String sql = """
            SELECT COALESCE(SUM(price * quantity), 0) 
            FROM products
            """;

        Query query = entityManager.createNativeQuery(sql);
        BigDecimal result = (BigDecimal) query.getSingleResult();
        return result != null ? result : BigDecimal.ZERO;
    }

    /**
     * Получить статистику товаров
     */
    public Map<String, Object> getProductsStatistics() {
        Map<String, Object> stats = new HashMap<>();

        // Общее количество товаров
        stats.put("totalProducts", getTotalProducts());

        // Общая стоимость инвентаря
        stats.put("totalInventoryValue", getTotalInventoryValue());

        // Средняя цена товара
        String avgPriceSql = "SELECT AVG(price) FROM products";
        Query avgPriceQuery = entityManager.createNativeQuery(avgPriceSql);
        BigDecimal avgPrice = (BigDecimal) avgPriceQuery.getSingleResult();
        stats.put("averagePrice", avgPrice != null ? avgPrice : BigDecimal.ZERO);

        // Общее количество товаров на складе
        String totalStockSql = "SELECT SUM(quantity) FROM products";
        Query totalStockQuery = entityManager.createNativeQuery(totalStockSql);
        Long totalStock = ((Number) totalStockQuery.getSingleResult()).longValue();
        stats.put("totalStock", totalStock != null ? totalStock : 0L);

        // Количество товаров с низким запасом
        List<Object[]> lowStock = getLowStockProducts(10);
        stats.put("lowStockCount", lowStock.size());

        // Количество товаров без категории
        String noCategorySql = "SELECT COUNT(*) FROM products WHERE category_id IS NULL";
        Query noCategoryQuery = entityManager.createNativeQuery(noCategorySql);
        Long noCategoryCount = ((Number) noCategoryQuery.getSingleResult()).longValue();
        stats.put("noCategoryCount", noCategoryCount);

        return stats;
    }

    /**
     * Получить самые дорогие товары
     */
    public List<Object[]> getMostExpensiveProducts(int limit) {
        String sql = """
            SELECT p.id, p.name, p.article, p.price, p.quantity,
                   (p.price * p.quantity) as total_value
            FROM products p
            ORDER BY p.price DESC
            LIMIT :limit
            """;

        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("limit", limit);

        return query.getResultList();
    }

    /**
     * Получить товары, которые скоро закончатся
     */
    public List<Object[]> getProductsRunningOut() {
        String sql = """
            SELECT p.id, p.name, p.article, p.price, p.quantity,
                   CASE 
                       WHEN p.quantity = 0 THEN 'ЗАКОНЧИЛСЯ'
                       WHEN p.quantity < 3 THEN 'ОЧЕНЬ МАЛО'
                       WHEN p.quantity < 10 THEN 'МАЛО'
                       ELSE 'ДОСТАТОЧНО'
                   END as stock_level
            FROM products p
            WHERE p.quantity < 10
            ORDER BY p.quantity ASC
            """;

        Query query = entityManager.createNativeQuery(sql);
        return query.getResultList();
    }

    /**
     * Получить распределение товаров по количеству
     */
    public Map<String, Long> getStockDistribution() {
        String sql = """
            SELECT 
                CASE 
                    WHEN quantity = 0 THEN 'Нет в наличии'
                    WHEN quantity < 5 THEN 'Очень мало (<5)'
                    WHEN quantity < 10 THEN 'Мало (5-9)'
                    WHEN quantity < 50 THEN 'Средне (10-49)'
                    WHEN quantity < 100 THEN 'Много (50-99)'
                    ELSE 'Очень много (100+)'
                END as stock_range,
                COUNT(*) as count
            FROM products
            GROUP BY 
                CASE 
                    WHEN quantity = 0 THEN 'Нет в наличии'
                    WHEN quantity < 5 THEN 'Очень мало (<5)'
                    WHEN quantity < 10 THEN 'Мало (5-9)'
                    WHEN quantity < 50 THEN 'Средне (10-49)'
                    WHEN quantity < 100 THEN 'Много (50-99)'
                    ELSE 'Очень много (100+)'
                END
            ORDER BY MIN(quantity)
            """;

        Query query = entityManager.createNativeQuery(sql);
        List<Object[]> results = query.getResultList();

        return results.stream()
                .collect(Collectors.toMap(
                        row -> (String) row[0],
                        row -> ((Number) row[1]).longValue()
                ));
    }

    /**
     * Получить товары для перезаказа
     */
    public List<Product> getProductsForReorder(int reorderPoint) {
        return productRepository.findAll().stream()
                .filter(product -> product.getQuantity() <= reorderPoint)
                .sorted((p1, p2) -> Integer.compare(p1.getQuantity(), p2.getQuantity()))
                .collect(Collectors.toList());
    }

    /**
     * Импортировать товары (простейшая версия)
     */
    @Transactional
    public List<Product> importProducts(List<Map<String, Object>> productsData) {
        List<Product> importedProducts = new ArrayList<>();

        for (Map<String, Object> data : productsData) {
            Product product = new Product();

            if (data.containsKey("name")) {
                product.setName((String) data.get("name"));
            }

            if (data.containsKey("article")) {
                product.setArticle((String) data.get("article"));
            }

            if (data.containsKey("price")) {
                if (data.get("price") instanceof Number) {
                    product.setPrice(BigDecimal.valueOf(((Number) data.get("price")).doubleValue()));
                } else if (data.get("price") instanceof String) {
                    product.setPrice(new BigDecimal((String) data.get("price")));
                }
            }

            if (data.containsKey("quantity")) {
                if (data.get("quantity") instanceof Number) {
                    product.setQuantity(((Number) data.get("quantity")).intValue());
                }
            }

            if (data.containsKey("categoryId")) {
                Long categoryId = ((Number) data.get("categoryId")).longValue();
                Category category = categoryRepository.findById(categoryId).orElse(null);
                product.setCategory(category);
            }

            Product savedProduct = productRepository.save(product);
            importedProducts.add(savedProduct);
        }

        return importedProducts;
    }

    /**
     * Поиск товаров с фильтрами
     */
    public List<Product> searchProductsWithFilters(String name, Long categoryId,
                                                   BigDecimal minPrice, BigDecimal maxPrice,
                                                   Integer minQuantity, Integer maxQuantity) {
        // Это упрощенная версия, в реальном проекте лучше использовать Specification
        List<Product> allProducts = productRepository.findAll();

        return allProducts.stream()
                .filter(product -> name == null || product.getName().toLowerCase().contains(name.toLowerCase()))
                .filter(product -> categoryId == null ||
                        (product.getCategory() != null && product.getCategory().getId().equals(categoryId)))
                .filter(product -> minPrice == null || product.getPrice().compareTo(minPrice) >= 0)
                .filter(product -> maxPrice == null || product.getPrice().compareTo(maxPrice) <= 0)
                .filter(product -> minQuantity == null || product.getQuantity() >= minQuantity)
                .filter(product -> maxQuantity == null || product.getQuantity() <= maxQuantity)
                .collect(Collectors.toList());
    }
}