// src/main/java/com/finuniversity/store_system/service/ExportService.java
package com.finuniversity.store_system.service;

import com.finuniversity.store_system.entity.Sale;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class ExportService {

    @Autowired
    private SaleService saleService;

    public byte[] exportSalesToExcel(LocalDate startDate, LocalDate endDate) throws IOException {
        List<Sale> sales = saleService.getSalesByDateRange(startDate, endDate);

        try (Workbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Продажи");

            // Стили
            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            // Заголовки
            Row headerRow = sheet.createRow(0);
            String[] headers = {
                    "ID", "Дата", "Время", "Кассир", "Товаров",
                    "Сумма", "Способ оплаты", "Статус"
            };

            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Данные
            int rowNum = 1;
            for (Sale sale : sales) {
                Row row = sheet.createRow(rowNum++);

                row.createCell(0).setCellValue(sale.getId());
                row.createCell(1).setCellValue(
                        sale.getSaleDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
                );
                row.createCell(2).setCellValue(
                        sale.getSaleDate().format(DateTimeFormatter.ofPattern("HH:mm"))
                );
                row.createCell(3).setCellValue(sale.getCashier().getUsername());
                row.createCell(4).setCellValue(sale.getItems().size());
                row.createCell(5).setCellValue(sale.getTotalAmount().doubleValue());
                row.createCell(6).setCellValue(getPaymentMethodText(sale.getPaymentMethod()));
                row.createCell(7).setCellValue(getStatusText(sale.getStatus()));
            }

            // Авторазмер колонок
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(outputStream);
            return outputStream.toByteArray();
        }
    }

    private String getPaymentMethodText(String method) {
        if (method == null) return "Не указан";

        switch (method) {
            case "cash": return "Наличные";
            case "card": return "Карта";
            case "transfer": return "Перевод";
            default: return method;
        }
    }

    private String getStatusText(String status) {
        if (status == null) return "Не указан";

        switch (status) {
            case "completed": return "Завершено";
            case "pending": return "В обработке";
            case "cancelled": return "Отменено";
            default: return status;
        }
    }
}