// src/main/java/com/finuniversity/store_system/service/SaleService.java
package com.finuniversity.store_system.service;

import com.finuniversity.store_system.entity.*;
import com.finuniversity.store_system.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class SaleService {

    @Autowired
    private SaleRepository saleRepository;

    @Autowired
    private SaleItemRepository saleItemRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CartService cartService;

    @Autowired
    private UserService userService;

    // ==================== МЕТОДЫ ДЛЯ ПОШАГОВОГО СОЗДАНИЯ ПРОДАЖИ ====================

    /**
     * Создать новую продажу (старый метод - сохраняем для обратной совместимости)
     */
    public Sale createSale() {
        Sale sale = new Sale();
        sale.setSaleDate(LocalDateTime.now());
        sale.setTotalAmount(BigDecimal.ZERO);
        sale.setStatus("pending"); // Добавляем статус по умолчанию
        return sale;
    }

    /**
     * Добавить товар в продажу (старый метод - улучшаем)
     */
    public Sale addProductToSale(Sale sale, Long productId, Integer quantity) {
        if (sale == null || productId == null || quantity <= 0) {
            throw new IllegalArgumentException("Некорректные параметры");
        }

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Товар не найден"));

        // Проверяем остаток
        if (product.getQuantity() < quantity) {
            throw new RuntimeException("Недостаточно товара. Доступно: " + product.getQuantity());
        }

        // Ищем, есть ли уже этот товар в продаже
        SaleItem existingItem = sale.getItems().stream()
                .filter(item -> item.getProduct().getId().equals(productId))
                .findFirst()
                .orElse(null);

        if (existingItem != null) {
            // Обновляем количество
            existingItem.setQuantity(existingItem.getQuantity() + quantity);
            existingItem.calculateSubtotal();
        } else {
            // Создаем новый элемент
            SaleItem newItem = new SaleItem();
            newItem.setSale(sale);
            newItem.setProduct(product);
            newItem.setQuantity(quantity);
            newItem.setPrice(product.getPrice());
            newItem.calculateSubtotal();

            sale.getItems().add(newItem);
        }

        // Обновляем общую сумму
        sale.calculateTotal();

        return sale;
    }

    /**
     * Удалить товар из продажи (старый метод - улучшаем)
     */
    public Sale removeProductFromSale(Sale sale, Long productId) {
        if (sale == null || productId == null) {
            throw new IllegalArgumentException("Некорректные параметры");
        }

        SaleItem itemToRemove = sale.getItems().stream()
                .filter(item -> item.getProduct().getId().equals(productId))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Товар не найден в продаже"));

        sale.getItems().remove(itemToRemove);
        sale.calculateTotal();

        return sale;
    }

    /**
     * Завершить продажу (старый метод - улучшаем с поддержкой способа оплаты)
     */
    public Sale completeSale(Sale sale, Long cashierId) {
        if (sale.getItems().isEmpty()) {
            throw new RuntimeException("Невозможно завершить пустую продажу");
        }

        User cashier = userRepository.findById(cashierId)
                .orElseThrow(() -> new RuntimeException("Кассир не найден"));

        // Устанавливаем кассира и способ оплаты
        sale.setCashier(cashier);
        String paymentMethod = "";
        sale.setPaymentMethod(paymentMethod);
        sale.setStatus("completed");
        sale.setSaleDate(LocalDateTime.now());

        // Обновляем остатки товаров
        for (SaleItem item : sale.getItems()) {
            Product product = item.getProduct();
            int newQuantity = product.getQuantity() - item.getQuantity();

            if (newQuantity < 0) {
                throw new RuntimeException("Недостаточно товара: " + product.getName());
            }

            product.setQuantity(newQuantity);
            productRepository.save(product);

            // Сохраняем элемент продажи
            item.setSale(sale);
            saleItemRepository.save(item);
        }

        // Сохраняем продажу
        return saleRepository.save(sale);
    }

    // ==================== МЕТОДЫ ДЛЯ РАБОТЫ С КОРЗИНОЙ ====================

    /**
     * Создать продажу из корзины текущего пользователя (новый метод)
     */
    @Transactional
    public Sale createSaleFromCart(String paymentMethod) {
        Cart cart = cartService.getOrCreateCart();

        if (cart.getItems().isEmpty()) {
            throw new RuntimeException("Корзина пуста");
        }

        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User cashier = (User) userService.loadUserByUsername(username);

        Sale sale = new Sale();
        sale.setCashier(cashier);
        sale.setPaymentMethod(paymentMethod);
        sale.setStatus("completed");
        sale.setSaleDate(LocalDateTime.now());

        List<SaleItem> saleItems = new ArrayList<>();

        for (CartItem cartItem : cart.getItems()) {
            Product product = cartItem.getProduct();

            // Проверяем остаток еще раз
            if (product.getQuantity() < cartItem.getQuantity()) {
                throw new RuntimeException("Недостаточно товара: " + product.getName());
            }

            // Уменьшаем остаток
            product.setQuantity(product.getQuantity() - cartItem.getQuantity());
            productRepository.save(product);

            // Создаем SaleItem
            SaleItem saleItem = new SaleItem();
            saleItem.setSale(sale);
            saleItem.setProduct(product);
            saleItem.setQuantity(cartItem.getQuantity());
            saleItem.setPrice(product.getPrice());
            saleItem.calculateSubtotal();

            saleItems.add(saleItem);
        }

        sale.setItems(saleItems);
        sale.calculateTotal();

        Sale savedSale = saleRepository.save(sale);

        // Сохраняем все элементы продажи
        for (SaleItem item : saleItems) {
            item.setSale(savedSale);
            saleItemRepository.save(item);
        }

        // Очищаем корзину
        cartService.clearCart();

        return savedSale;
    }

    // ==================== МЕТОДЫ ДЛЯ ПОЛУЧЕНИЯ ДАННЫХ ====================

    /**
     * Получить все продажи
     */
    public List<Sale> getAllSales() {
        return saleRepository.findAllOrderByDateDesc();
    }

    /**
     * Получить продажи за период
     */
    public List<Sale> getSalesByDateRange(LocalDate startDate, LocalDate endDate) {
        if (startDate == null || endDate == null) {
            return getAllSales();
        }

        return saleRepository.findBySaleDateBetween(
                startDate.atStartOfDay(),
                endDate.plusDays(1).atStartOfDay()
        );
    }

    /**
     * Получить продажу по ID
     */
    public Sale getSaleById(Long id) {
        return saleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Продажа не найдена"));
    }

    /**
     * Получить статистику продаж за период (старый метод - расширяем)
     */
    public Map<String, Object> getSalesStatistics(LocalDate startDate, LocalDate endDate) {
        List<Sale> sales = getSalesByDateRange(startDate, endDate);

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalSales", sales.size());

        BigDecimal totalRevenue = sales.stream()
                .map(Sale::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        stats.put("totalRevenue", totalRevenue);

        BigDecimal averageCheck = sales.isEmpty() ? BigDecimal.ZERO :
                totalRevenue.divide(BigDecimal.valueOf(sales.size()), 2, BigDecimal.ROUND_HALF_UP);
        stats.put("averageCheck", averageCheck);

        // Добавляем дополнительные статистики из нового кода
        if (!sales.isEmpty()) {
            // Продажи за последние 30 дней
            LocalDate monthAgo = LocalDate.now().minusDays(30);
            long recentSales = sales.stream()
                    .filter(sale -> sale.getSaleDate().toLocalDate().isAfter(monthAgo))
                    .count();
            stats.put("recentSales", recentSales);

            // Максимальный и минимальный чек
            Optional<BigDecimal> maxCheck = sales.stream()
                    .map(Sale::getTotalAmount)
                    .max(BigDecimal::compareTo);
            Optional<BigDecimal> minCheck = sales.stream()
                    .map(Sale::getTotalAmount)
                    .min(BigDecimal::compareTo);

            stats.put("maxCheck", maxCheck.orElse(BigDecimal.ZERO));
            stats.put("minCheck", minCheck.orElse(BigDecimal.ZERO));

            // Статистика по способам оплаты
            Map<String, Long> paymentMethods = sales.stream()
                    .collect(Collectors.groupingBy(
                            Sale::getPaymentMethod,
                            Collectors.counting()
                    ));
            stats.put("paymentMethods", paymentMethods);

            // Количество проданных товаров
            long totalItemsSold = sales.stream()
                    .flatMap(sale -> sale.getItems().stream())
                    .mapToLong(SaleItem::getQuantity)
                    .sum();
            stats.put("totalItemsSold", totalItemsSold);
        }

        return stats;
    }

    /**
     * Получить статистику продаж за все время (новый метод)
     */
    public Map<String, Object> getSalesStatistics() {
        return getSalesStatistics(null, null);
    }

    /**
     * Получить выручку по месяцам
     */
    public Map<YearMonth, BigDecimal> getMonthlyRevenue() {
        List<Sale> allSales = getAllSales();

        return allSales.stream()
                .collect(Collectors.groupingBy(
                        sale -> YearMonth.from(sale.getSaleDate()),
                        Collectors.reducing(
                                BigDecimal.ZERO,
                                Sale::getTotalAmount,
                                BigDecimal::add
                        )
                ));
    }

    /**
     * Получить статистику по способам оплаты
     */
    public Map<String, Long> getSalesByPaymentMethod() {
        List<Sale> allSales = getAllSales();

        return allSales.stream()
                .collect(Collectors.groupingBy(
                        Sale::getPaymentMethod,
                        Collectors.counting()
                ));
    }

    /**
     * Получить ежедневную статистику за последние 30 дней
     */
    public Map<LocalDate, DailySalesStats> getDailySalesStatsLast30Days() {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusDays(30);

        List<Sale> sales = getSalesByDateRange(startDate, endDate);

        Map<LocalDate, DailySalesStats> dailyStats = new TreeMap<>();

        // Инициализируем все дни в диапазоне
        for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
            dailyStats.put(date, new DailySalesStats(date));
        }

        // Заполняем статистику
        sales.forEach(sale -> {
            LocalDate saleDate = sale.getSaleDate().toLocalDate();
            DailySalesStats stats = dailyStats.get(saleDate);
            if (stats != null) {
                stats.addSale(sale);
            }
        });

        return dailyStats;
    }

    /**
     * Отменить продажу (вернуть товары на склад)
     */
    @Transactional
    public void cancelSale(Long saleId) {
        Sale sale = getSaleById(saleId);

        if ("cancelled".equals(sale.getStatus())) {
            throw new RuntimeException("Продажа уже отменена");
        }

        // Возвращаем товары на склад
        for (SaleItem item : sale.getItems()) {
            Product product = item.getProduct();
            product.setQuantity(product.getQuantity() + item.getQuantity());
            productRepository.save(product);
        }

        // Меняем статус продажи
        sale.setStatus("cancelled");
        saleRepository.save(sale);
    }

    /**
     * Класс для хранения ежедневной статистики
     */
    public static class DailySalesStats {
        private LocalDate date;
        private int salesCount = 0;
        private BigDecimal totalRevenue = BigDecimal.ZERO;
        private int totalItems = 0;

        public DailySalesStats(LocalDate date) {
            this.date = date;
        }

        public void addSale(Sale sale) {
            this.salesCount++;
            this.totalRevenue = this.totalRevenue.add(sale.getTotalAmount());
            this.totalItems += sale.getItems().stream()
                    .mapToInt(SaleItem::getQuantity)
                    .sum();
        }

        // Геттеры
        public LocalDate getDate() { return date; }
        public int getSalesCount() { return salesCount; }
        public BigDecimal getTotalRevenue() { return totalRevenue; }
        public int getTotalItems() { return totalItems; }
        public BigDecimal getAverageCheck() {
            return salesCount == 0 ? BigDecimal.ZERO :
                    totalRevenue.divide(BigDecimal.valueOf(salesCount), 2, BigDecimal.ROUND_HALF_UP);
        }
    }

    /**
     * Получить топ товаров по продажам
     */
    public List<ProductSalesStats> getTopSellingProducts(int limit) {
        List<Sale> allSales = getAllSales();

        // Собираем статистику по товарам
        Map<Product, ProductSalesStats> statsMap = new HashMap<>();

        for (Sale sale : allSales) {
            for (SaleItem item : sale.getItems()) {
                Product product = item.getProduct();
                ProductSalesStats stats = statsMap.getOrDefault(product,
                        new ProductSalesStats(product));

                stats.addSale(item.getQuantity(), item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())));
                statsMap.put(product, stats);
            }
        }

        // Сортируем по количеству проданных единиц
        return statsMap.values().stream()
                .sorted((s1, s2) -> Integer.compare(s2.getTotalQuantitySold(), s1.getTotalQuantitySold()))
                .limit(limit)
                .collect(Collectors.toList());
    }

    /**
     * Класс для статистики продаж по товарам
     */
    public static class ProductSalesStats {
        private Product product;
        private int totalQuantitySold = 0;
        private BigDecimal totalRevenue = BigDecimal.ZERO;

        public ProductSalesStats(Product product) {
            this.product = product;
        }

        public void addSale(int quantity, BigDecimal revenue) {
            this.totalQuantitySold += quantity;
            this.totalRevenue = this.totalRevenue.add(revenue);
        }

        // Геттеры
        public Product getProduct() { return product; }
        public int getTotalQuantitySold() { return totalQuantitySold; }
        public BigDecimal getTotalRevenue() { return totalRevenue; }
        public BigDecimal getAveragePrice() {
            return totalQuantitySold == 0 ? BigDecimal.ZERO :
                    totalRevenue.divide(BigDecimal.valueOf(totalQuantitySold), 2, BigDecimal.ROUND_HALF_UP);
        }
    }
}