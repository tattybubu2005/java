package com.finuniversity.store_system.service;

import com.finuniversity.store_system.entity.Role;
import com.finuniversity.store_system.entity.User;
import com.finuniversity.store_system.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements UserDetailsService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, BCryptPasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("Пользователь не найден: " + username);
        }
        return user;
    }


    public void registerUser(User user) {
        // Хешируем пароль перед сохранением
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    // Создаем администратора по умолчанию, если нет пользователей
    public void createDefaultAdmin() {
        if (userRepository.count() == 0) {
            User admin = new User("admin", "admin123", Role.ADMIN);
            admin.setPassword(passwordEncoder.encode(admin.getPassword()));
            userRepository.save(admin);
            System.out.println("Создан администратор по умолчанию: admin / admin123");
        }
    }
}