package com.finuniversity.store_system.repository;

import com.finuniversity.store_system.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByNameContainingIgnoreCase(String name);
    List<Product> findByArticleContainingIgnoreCase(String article);
    List<Product> findByCategoryId(Long categoryId);

    // Для поиска по количеству
    List<Product> findByQuantityLessThan(Integer quantity);
    List<Product> findByQuantityGreaterThan(Integer quantity);

    // Для поиска по цене
    List<Product> findByPriceLessThanEqual(Double price);
    List<Product> findByPriceGreaterThanEqual(Double price);
    // Spring Data JPA автоматически создаст базовые методы:
// src/main/java/com/finuniversity/store_system/repository/ProductRepository.java
}