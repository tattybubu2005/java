// src/main/java/com/finuniversity/store_system/service/CartService.java
package com.finuniversity.store_system.service;

import com.finuniversity.store_system.entity.*;
import com.finuniversity.store_system.repository.CartRepository;
import com.finuniversity.store_system.repository.CartItemRepository;
import com.finuniversity.store_system.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserService userService;

    public Cart getOrCreateCart() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = (User) userService.loadUserByUsername(username);

        Optional<Cart> existingCart = cartRepository.findByUser(user);
        if (existingCart.isPresent()) {
            return existingCart.get();
        } else {
            Cart cart = new Cart(user);
            return cartRepository.save(cart);
        }
    }

    @Transactional
    public void addToCart(Long productId, Integer quantity) {
        Cart cart = getOrCreateCart();
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Проверяем остаток
        if (product.getQuantity() < quantity) {
            throw new RuntimeException("Not enough stock");
        }

        // Проверяем, есть ли уже товар в корзине
        Optional<CartItem> existingItem = cart.getItems().stream()
                .filter(item -> item.getProduct().getId().equals(productId))
                .findFirst();

        if (existingItem.isPresent()) {
            CartItem item = existingItem.get();
            item.setQuantity(item.getQuantity() + quantity);
            cartItemRepository.save(item);
        } else {
            CartItem newItem = new CartItem(cart, product, quantity);
            newItem.setPrice(product.getPrice().doubleValue());
            cart.getItems().add(newItem);
            cartItemRepository.save(newItem);
        }
    }

    @Transactional
    public void updateCartItem(Long itemId, Integer quantity) {
        CartItem item = cartItemRepository.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));

        if (quantity <= 0) {
            cartItemRepository.delete(item);
        } else {
            item.setQuantity(quantity);
            cartItemRepository.save(item);
        }
    }

    @Transactional
    public void removeFromCart(Long itemId) {
        cartItemRepository.deleteById(itemId);
    }

    @Transactional
    public void clearCart() {
        Cart cart = getOrCreateCart();
        cartItemRepository.deleteByCartId(cart.getId());
        cart.getItems().clear();
    }

    public Double getCartTotal() {
        Cart cart = getOrCreateCart();
        return cart.getTotalAmount();
    }

    public Integer getCartItemCount() {
        Cart cart = getOrCreateCart();
        return cart.getItems().stream()
                .mapToInt(CartItem::getQuantity)
                .sum();
    }
}