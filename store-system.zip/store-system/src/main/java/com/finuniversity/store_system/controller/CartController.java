// src/main/java/com/finuniversity/store_system/controller/CartController.java
package com.finuniversity.store_system.controller;

import com.finuniversity.store_system.entity.Cart;
import com.finuniversity.store_system.service.CartService;
import com.finuniversity.store_system.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/cart")
@PreAuthorize("hasAnyRole('ADMIN', 'CASHIER')")
public class CartController {

    @Autowired
    private CartService cartService;

    @Autowired
    private ProductService productService;


    @GetMapping
    public String viewCart(Model model) {
        Cart cart = cartService.getOrCreateCart();
        model.addAttribute("cart", cart);
        model.addAttribute("totalAmount", cartService.getCartTotal());
        return "cart/view";
    }

    @PostMapping("/add")
    public String addToCart(@RequestParam Long productId,
                            @RequestParam(defaultValue = "1") Integer quantity) {
        try {
            cartService.addToCart(productId, quantity);
            return "redirect:/cart?success=Товар добавлен в корзину";
        } catch (RuntimeException e) {
            return "redirect:/products?error=" + e.getMessage();
        }
    }

    @PostMapping("/update/{itemId}")
    public String updateCartItem(@PathVariable Long itemId,
                                 @RequestParam Integer quantity) {
        cartService.updateCartItem(itemId, quantity);
        return "redirect:/cart";
    }

    @PostMapping("/remove/{itemId}")
    public String removeFromCart(@PathVariable Long itemId) {
        cartService.removeFromCart(itemId);
        return "redirect:/cart";
    }

    @PostMapping("/clear")
    public String clearCart() {
        cartService.clearCart();
        return "redirect:/cart";
    }

    @GetMapping("/checkout")
    public String checkoutPage(Model model) {
        Cart cart = cartService.getOrCreateCart();
        if (cart.getItems().isEmpty()) {
            return "redirect:/cart?error=Корзина пуста";
        }

        model.addAttribute("cart", cart);
        model.addAttribute("totalAmount", cartService.getCartTotal());
        return "cart/checkout";
    }
}