package com.finuniversity.store_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
